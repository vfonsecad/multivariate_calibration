file_name;description;Ben Aernouts paper 2010-2011 Visible and near-infrared spectroscopic analysis of raw milk for cow health monitoring: Reflectance or transmittance?
Transmittance_DataPrepared.mat;xcal,xval,ycal,yval structure
Transmittance_KS_DataPrepared.mat;xcal,xval,ycal,yval structure and val samples were chosen with KS alg (30 val samples)Fat-Prot-Lact-SCC-Urea-Group-DayCol-DayAn
Reflectance_KS_DataPrepared.mat;xcal,xval,ycal,yval structure and val samples were chosen with KS alg (30 val samples)Fat-Prot-Lact-SCC-Urea-Group-DayCol-DayAn
Reflectance_VISNIR.csv;all data, ycal and xcal reflectance
Reflectance_VISNIR_wv_names.csv;wavelength number in nm reflectance
Reflectance_VISNIR_xcal.csv;spectra xcal reflectance
Reflectance_VISNIR_xval.csv;same data as in xcal reflectance (kept for format purposes)
Reflectance_VISNIR_ycal.csv;ycal 5 parameters and farm
Reflectance_VISNIR_yval.csv;copy of ycal reflectance
Reflectance_VISNIR_yy_names.csv;names of y parameters
Transmittance_VISNIR.csv;all data, ycal and xcal transmittance
Transmittance_VISNIR_x_wv.csv;wavelength number in nm transmittance
Transmittance_VISNIR_y_constituent.csv;y parameters names
Transmittance_KSval_DataPrepared.mat;robpca KS sample for val set
trans-ksval_data-prep.mat;robpca KS sample for val set
trans_randval_data-prep.mat;random sample for validation of transmittance data, 20 percent of the total data for validation
trans_lactose_preproc_randval_data_prepared.mat; SG1D and OSC (lactose) preprocessing on absorbance as indicated in Ben paper table 5, 8th model
FOLDER_ID;2019_01_31_0008;
